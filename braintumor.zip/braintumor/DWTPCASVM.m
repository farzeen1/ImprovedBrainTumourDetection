% Project Title: Brain MRI Classification using SVM with DWT & PCA

close all
clc
clear
[filename, pathname] = uigetfile({'*.*, *.png, *.jpeg, *.bmp, *.jpg'}, 'C:\Users\fxrze\OneDrive\Desktop\Final Year Project\Brain_Tumor\Brain_Tumor_Code\MRI Images');
if isequal(filename, 0)||isequal(pathname, 0)
    f = warndlg('Your request has been cancelled');
else
    I = imread([pathname, filename]);
    I = imresize(I,[500, 700]);
end

%-----Segmententation of Image with Otsu Binarization------
% Convert image to grayscale
gray = rgb2gray(I);

% Calculate threshold
level = graythresh(I);

% Apply level to convert image into binary
BW = imbinarize(I);

%Show binarized image
imshow(I);

%Segment tumour using K means clustering into 3 regions
[L,Centers] = imsegkmeans(I,3);
segImage = labeloverlay(I,L);
figure, imshow(segImage)
title('K means')

%Convert RBG image to L*a*b
rgb = imread("mri.tif");
conversionform = makecform('srgb2lab');
lab_img = applycform(segImage, conversionform);
figure, imshow(lab_img)
title ('L*a*b Image')

% Classify the colors in a*b* colorspace using K-Means clustering.
% The image has three colours therefore 3 clusters are required.
 ab = lab_img(:,:,2,1);
 ab = im2single(ab);
 
 nColors = 3;

% Measure the distance using Euclidean Distance Metric.
[cluster_idx, cluster_center] = kmeans(ab,nColors,'distance','sqEuclidean', ...
                                      'Replicates',3);

pixel_labels = imsegkmeans(ab,nColors,'NumAttempts',3);

% Using K means label/classify every pixel in the image with its cluster_index.
figure, imshow(pixel_labels,[])
title('Image labeled by cluster index')

% Create a blank cell array to store the results of clustering
segImage = cell(1,3);

% Create RGB label using pixel_labels
rgb_label = repmat(pixel_labels,[1,1,3]);

for k = 1:nColors
    colors = lab_img;
    colors(rgb_label ~= k) = 0;
    segImage{k} = colors;
end

figure, imshow(segImage{1});
title('Objects in Cluster 1');
figure, imshow(segImage{2});
title('Objects in Cluster 2');
figure, imshow(segImage{3});
title('Objects in Cluster 3');

SegmentedTumour = imbinarize(segImage{1});
title ('Segmented Tumour');
img = SegmentedTumour;

%-----Feature extraction using DWT---------
x = double(SegmentedTumour);
m = size(SegmentedTumour,1);
n = size(SegmentedTumour,2);
signal1 = (rand(m,1));
Winsize = floor(size(x,1));
winsize = int32(10);
wininc = int32(8);
warning('Decomposition levels are selected automatically')
J = int32(floor(log(size(x,1))))/log(2);
Features = getmswpfeat(Signal, winsize, wininc, J,'Matlab');

m = size(img, 1);
Signal = rand(m,1);
SegmentedTumour = signal1(:,:);
Feat = getmswpfeat(Signal, winsize, wininc, J, 'Matlab');
toolbox = 'Matlab';
Features = getmswpfeat(Signal, winsize, wininc, J, 'Matlab');
signal1 = thr(:,:);

[cA1, cH1, cV1, cD1] = dwt2(signal1, 'db4');
[cA2, cH2, cV2, cD2] = dwt2(cA1,'db4');
[cA3, cH3, cV3, cD3] = dwt2(cA2, 'db4');
DWT_feat = [cA3, cH3, cV3, cD3];

figure, imshow(imresize(DWT_feat,[200,550]));

G = pca(DWT_feat);
whos DWT_feat
whos G
g = graycomatrix(G);
stats = graycoprops(glcm,{'Contrast, Correlation, Energy, Homogeneity'});
Contrast = stats.Contrast;
Correlation = stats.Correlation;
Energy = stats.Energy;
Homongeneity = stats.Homogeneity;
Mean = mean2(G);
Standard_Deviation = std2(G);
Entropy = entropy(G);
RMS = mean2(rms(G));
%Skewness = skewness(img);
Variance = mean2(var(double(G)));
a = sum(double(G(:)));
Smoothness = 1-(1/(1+a));
Kurtosis = kurtosis(double(G(:)));
Skewness = skewness(double(G(:)));
Inverse Difference Movement
m = size(G,1);
n = size(G,2);
in_diff = 0;
for i = 1:m
    for j = 1:n
        temp = G(i,j)./(1+(i-j).^2);
        in_diff = in_diff+temp;
   end
end
IDM = double(in_diff);
   
feat = [Contrast, Correlation, Energy, Homogeneity, Mean, Standard_Deviation, Entropy, RMS, Variance, Smoothness, Kurtosis, Skewness, IDM];

% Normalize features to have zero mean and unit variance
feat = real(feat);
feat = (feat-mean(feat(:)));
feat=feat/std(feat(:));
DWT_Features = cell2mat(DWT_feat);
mean = mean(DWT_feat(:));
feat1 = getmswpfeat(signal1,20,2,2,'matlab');
signal2 = rand(n,1);
feat2 = getmswpfeat(signal2,200,6,2,'matlab');
feat2 = getmswpfeat(signal2,20,2,2,'matlab');

% Combine features
features = [feat1;feat2];

% Apply PCA to reduce dimensionality
coeff = pca(features);

% Check dimensionality reduction
whos features
whos coeff
load Trainset.mat
xdata = meas;
group = label;
svmStruct = fitcsvm(xdata,group,'showplot',false);
species = ClassificationSVM(svmStruct,feat);
svmStruct1 = fitcsvm(xdata,group,'kernel_function', 'linear');
cp = classperf(group);
feat1 = [0.1889 0.9646 0.4969 0.9588 31.3445 53.4054 3.0882 6.0023 1.2971e+03 1.0000 4.3694 1.5752 255];
feat2 = [ 0.2790 0.9792 0.4229 0.9764 64.4934 88.6850 3.6704 8.4548 2.3192e+03 1.0000 1.8148 0.7854 255];
species = ClassificationSVM(svmStruct1,feat,'showplot',false);
classperf(cp,species,feat2);
classperf(cp,feat2);
Accuracy = cp.CorrectRate;
Accuracy = Accuracy*100;

% Polynomial Kernel
svmStruct2 = fitcsvm(xdata,group,'Polyorder',2,'Kernel_Function','polynomial');
species_Poly = ClassificationSVM(svmStruct2,feat,'showplot',false);
 
% Quadratic Kernel
svmStruct3 = fitcsvm(xdata,group,'Kernel_Function','quadratic');
species_Quad = ClassificationSVM(svmStruct3,feat,'showplot',false);
 
% RBF Kernel
svmStruct4 = fitcsvm(xdata,group,'RBF_Sigma', 3,'Kernel_Function','rbf','boxconstraint',Inf);
species_RBF = ClassificationSVM(svmStruct4,feat,'showplot',false);

% To plot classification graphs, SVM can take only two dimensional data
data1   = [meas(:,1), meas(:,2)];
newfeat = [feat(:,1),feat(:,2)];

pause
close all

svmStruct1_new = fitcsvm(data1,group,'kernel_function', 'linear','showplot',false);
species_Linear_new = ClassificationSVM(svmStruct1_new,newfeat,'showplot',false);

%%
% Multiple runs for accuracy highest is 90%
load Trainset.mat
data = [meas(:,1), meas(:,2)];
data = meas;
groups = ismember(label,'BENIGN');
groups = ismember(label,'MALIGNANT');
[train,test] = crossvalind('HoldOut',groups);
cp = classperf(groups);
svmStruct = fitcsvm(data(train,:),groups(train),'boxconstraint',Inf,'showplot',false,'kernel_function','rbf');
svmStruct = fitcsvm(data(train,:),groups(train),'showplot',false,'kernel_function','linear');
classes = ClassificationSVM(svmStruct,data(test,:),'showplot',false);
classperf(cp,classes,test);
Accuracy_Classification = cp.CorrectRate.*100;
sprintf('Accuracy of Linear kernel is: %g%%',Accuracy_Classification)

%% Accuracy with RBF
svmStruct_RBF = fitcsvm(data(train,:),groups(train),'boxconstraint',Inf,'showplot',false,'kernel_function','rbf');
classes2 = ClassificationSVM(svmStruct_RBF,data(test,:),'showplot',false);
classperf(cp,classes2,test);
Accuracy_Classification_RBF = cp.CorrectRate.*100;
sprintf('Accuracy of RBF kernel is: %g%%',Accuracy_Classification_RBF)

%% Accuracy with Polynomial
svmStruct_Poly = fitcsvm(data(train,:),groups(train),'Polyorder',2,'Kernel_Function','polynomial');
classes3 = CLassificationSVM(svmStruct_Poly,data(test,:),'showplot',false);
classperf(cp,classes3,test);
Accuracy_Classification_Poly = cp.CorrectRate.*100;
sprintf('Accuracy of Polynomial kernel is: %g%%',Accuracy_Classification_Poly)

%%

% 5 fold cross validation
% 5 fold cross validation
load Normalized_Features.mat
 xdata = norm_feat;
 group = norm_label;
indicies = crossvalind('Kfold',label,5);
cp = classperf(label);
for i = 1:length(label)
    test = (indicies==i);train = ~ test;
    svmStruct = fitcsvm(xdata(train,:),group(train),'boxconstraint',Inf,'showplot',false,'kernel_function','rbf');
    classes = ClassificationSVM(svmStruct,xdata(test,:),'showplot',false);
    class = ClassificationSVM(meas(test,:),meas(train,:),label(train,:));
    classperf(cp,classes,test);
end
Accu = cp.ClassifiedRate;
Accuracy = cp.CorrectRate;
sprintf('Accuracy of classification with 5 fold cross validation is: %g%%',Accu*100)

%% Accuracy for normalized features
load Normalized_Features.mat
xdata = norm_feat;
data   = [xdata(:,1), xdata(:,2)];

groups = ismember(label,'BENIGN');
groups = ismember(label,'MALIGNANT');
[train,test] = crossvalind('HoldOut',groups);
cp = classperf(groups);
svmStruct = fitcsvm(data(train,:),groups(train),'boxconstraint',Inf,'showplot',false,'kernel_function','rbf');
svmStruct = fitcsvm(data(train,:),groups(train),'showplot',false,'kernel_function','linear');
classes = ClassificationSVM(svmStruct,data(test,:),'showplot',false);
classperf(cp,classes,test);
Accuracy_New = cp.CorrectRate.*100;
sprintf('Accuracy of classification is: %g%%',Accuracy_New);
%% Hold out on normalized features highest is 70%
load Normalized_Features.mat
xdata = norm_feat;
data = norm_feat;
group = norm_label;
groups = ismember(label,'BENIGN');
groups = ismember(label,'MALIGNANT');
[train,test] = crossvalind('HoldOut',groups);
cp = classperf(groups);
svmStruct = fitcsvm(data(train,:),groups(train),'boxconstraint',Inf,'showplot',false,'kernel_function','rbf');
svmStruct = fitcsvm(data(train,:),groups(train),'showplot',false,'kernel_function','linear');
classes = ClassificationSVM(svmStruct,data(test,:),'showplot',false);
classperf(cp,classes,test);
Accuracy_Classification = cp.CorrectRate.*100;
sprintf('Accuracy of classification is: %g%%', Accuracy_Classification) 

